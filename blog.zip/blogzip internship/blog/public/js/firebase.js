
  
 let firebaseConfig = {
    apiKey: "AIzaSyBj0AhUI_Mp9AJe1oAEZgXDO6mwXyvi2eI",
    authDomain: "blogging-website-15d0a.firebaseapp.com",
    projectId: "blogging-website-15d0a",
    storageBucket: "blogging-website-15d0a.appspot.com",
    messagingSenderId: "619169562761",
    appId: "1:619169562761:web:fb0e937031de1d23c80658",
    measurementId: "G-VTQG83H0PH"
  };

  // Initialize Firebase
  firebase.initializeApp(firebaseConfig);
let db=firebase.firestore();
